import React from 'react';
import Main from './components/Main';
import './App.css';

const App = () => {
  return (
    <div className="App">
      <Main />
    </div>
  );
};

export default App;
